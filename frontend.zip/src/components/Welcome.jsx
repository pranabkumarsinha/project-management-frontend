function Welcome(props) {
    return <div><h1>Wecome {props.name}</h1></div>
}

export default Welcome